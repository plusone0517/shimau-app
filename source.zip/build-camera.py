from pathlib import Path
import sys
root=Path(__file__).resolve().parent
html=(root/'base-index.html').read_text()
old='onClick:()=>Ae.current?.click()'
assert html.count(old)==1,'Camera handler changed; re-review integration before publishing'
html=html.replace(old,'onClick:()=>window.MediproCamera.openCamera({title:`もの・収納場所を撮影`}).then(e=>e&&ze(e))')
html=html.replace('`撮影する`','`カメラで撮影`')
css=(root/'camera.css').read_text()
js='(()=>{'+(root/'camera.js').read_text().replace('export function openCamera','function openCamera')+'})();'
html=html.replace('</head>','<style>'+css+'</style></head>')
html=html.replace('<body>','<body><script>'+js.replace('</script','<\\/script')+'</script>',1)
out=Path(sys.argv[1]) if len(sys.argv)>1 else root/'index.html'
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(html)
print(out)
