# しまう — camera source

The original published app is preserved in base-index.html. Build with `python3 build-camera.py index.html`. The script replaces only the existing camera click handler and embeds the shared capture UI; the existing photo and storage handlers are preserved.


## カメラ機能（2026-10-01）

写真が必要な画面から「カメラで撮影」を選べます。プレビュー、撮影、撮り直し、写真の確定、前面／背面切替に対応しています。カメラを開けない場合は「端末のカメラで撮影」または「写真から選ぶ」を使えます。HTTPS環境とカメラの使用許可が必要です。写真の既存の保存・読取り方法は変更していません。詳しい実装と検証範囲は source.zip 内の CAMERA_UPDATE.md を参照してください。
